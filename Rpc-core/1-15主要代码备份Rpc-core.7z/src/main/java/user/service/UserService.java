package user.service;

import user.bean.User;

import java.util.List;

public class UserService {
    public void save(User user) {

    }

    public void saveList(List<User> users) {

    }
}
