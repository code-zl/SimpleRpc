package netty.constant;

public class Constants {
    public static final String SERVER_Path="/netty/";
}
